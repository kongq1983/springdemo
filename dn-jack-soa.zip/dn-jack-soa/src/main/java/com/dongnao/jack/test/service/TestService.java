package com.dongnao.jack.test.service;

public interface TestService {

	public String eat(String param);
}
