package com.dongnao.jack.test;

public class UserServiceImpl implements UserService {
    
    public String eat(String param) {
        // TODO Auto-generated method stub
        return null;
    }
    
}
